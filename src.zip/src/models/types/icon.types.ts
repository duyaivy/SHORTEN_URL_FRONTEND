import { ComponentProps } from 'react'

export type IconSvgProps = ComponentProps<'svg'>
