export type UrlType = {
  url: string
  alias: string
  password?: string
}
export type QrHistory = {
  decoded: string
}
