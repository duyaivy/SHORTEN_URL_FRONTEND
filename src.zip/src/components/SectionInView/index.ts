import SectionInView from './SectionInView'

export default SectionInView
