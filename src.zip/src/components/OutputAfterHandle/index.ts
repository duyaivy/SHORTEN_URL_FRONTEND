import OutputAfterHandle from './OutputAfterHandle'

export default OutputAfterHandle
