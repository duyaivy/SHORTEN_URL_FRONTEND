import PaginationPage from './PaginationPage'

export default PaginationPage
