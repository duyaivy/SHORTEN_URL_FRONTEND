import ConfirmDeleteDialog from './ConfirmDeleteDialog'

export default ConfirmDeleteDialog
