import I18NextLanguage from './I18NextLanguage'

export default I18NextLanguage
