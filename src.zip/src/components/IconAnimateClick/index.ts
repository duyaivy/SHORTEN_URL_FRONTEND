import IconAnimateClick from './IconAnimateClick'

export default IconAnimateClick
