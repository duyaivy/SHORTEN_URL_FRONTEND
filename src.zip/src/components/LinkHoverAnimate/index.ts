import LinkHoverAnimate from './LinkHoverAnimate'

export default LinkHoverAnimate
