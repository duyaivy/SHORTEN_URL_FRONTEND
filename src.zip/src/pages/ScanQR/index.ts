import ScanQR from './ScanQR'

export default ScanQR
