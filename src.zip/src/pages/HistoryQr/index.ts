import HistoryQr from './HistoryQr'

export default HistoryQr
