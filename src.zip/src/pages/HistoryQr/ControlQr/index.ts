import ControlQr from './ControlQr'

export default ControlQr
