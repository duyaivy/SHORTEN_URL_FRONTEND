import ManageQr from './ManageQr'

export default ManageQr
