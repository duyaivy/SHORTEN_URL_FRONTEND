import ManageUrls from './ManageUrls'

export default ManageUrls
