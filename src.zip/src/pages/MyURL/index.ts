import MyURL from './MyURL'

export default MyURL
