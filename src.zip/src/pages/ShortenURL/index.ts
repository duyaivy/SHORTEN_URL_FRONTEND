import ShortenURL from './ShortenURL'

export default ShortenURL
