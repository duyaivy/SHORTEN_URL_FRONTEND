import AliasFetch from './AliasFetch'

export default AliasFetch
