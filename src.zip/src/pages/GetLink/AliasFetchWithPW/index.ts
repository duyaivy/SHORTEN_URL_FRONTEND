import AliasFetchWithPW from './AliasFetchWithPW'

export default AliasFetchWithPW
