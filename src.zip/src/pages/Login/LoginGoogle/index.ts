import LoginGoogle from './LoginGoogle'

export default LoginGoogle
