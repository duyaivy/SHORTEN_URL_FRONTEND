import LoginNowDialog from './LoginNowDialog'

export default LoginNowDialog
