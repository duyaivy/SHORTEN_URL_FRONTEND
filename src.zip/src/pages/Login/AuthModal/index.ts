import AuthModal from './AuthModal'

export default AuthModal
