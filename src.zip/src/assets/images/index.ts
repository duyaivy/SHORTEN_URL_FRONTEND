import logo from './logo.png'
import bg_dot from './dot.png'
export { logo, bg_dot }
