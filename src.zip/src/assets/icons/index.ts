import menuV2 from './menuV2.json'
import radioButton from './radioButton.json'
import trash from './trash.json'
import alert from './alert.json'
import loading from './loading.json'
export { menuV2, radioButton, trash, alert, loading }
