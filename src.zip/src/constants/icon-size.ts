export const ICON_SIZE_SMALL = 16
export const ICON_SIZE_MEDIUM = 20
export const ICON_SIZE_LARGE = 24
export const ICON_SIZE_EXTRA = 30
export const ICON_SIZE_XL = 40
